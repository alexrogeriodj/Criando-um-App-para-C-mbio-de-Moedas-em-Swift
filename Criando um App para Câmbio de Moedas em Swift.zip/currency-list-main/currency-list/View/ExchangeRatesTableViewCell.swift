//
//  ExchangeRatesTableViewCell.swift
//  currency-list
//
//  Created by Ludimila da bela cruz on 19/09/21.
//

import UIKit

class ExchangeRatesTableViewCell: UITableViewCell {

    @IBOutlet weak var rateValue: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
