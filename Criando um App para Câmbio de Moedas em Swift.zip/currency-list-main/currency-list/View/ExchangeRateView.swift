import UIKit

class ExchangeRateView: UIView {
    let viewController = ExchangeRateViewController()
    
    
}
